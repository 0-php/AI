#!/bin/bash -l

module unload intelmpi
module load pathmpi
mpicc -o ngram network.c analyze.c print_path.c graph_analysis.c analyze_v.c main.c  

echo "
    N-gram-patterns Copyright (C) 2007 Flamengo team
    This program comes with ABSOLUTELY NO WARRANTY;
    This is free software, and you are welcome to redistribute it
    under certain conditions;
"
qsub -v ROOT=$1,CUTOFF=$2,IFILE=$3 myscript -q bc -N Flamengo 
