input: a sample input we used on test_1
output: sample output
