Copyright (C) 2007 Flamengo team.
This file is part of the Fun with Google n-gram project.
   
Fun with Google n-gram is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Fun with Google n-gram is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.

Fun with Google n-gram should be running on MSI IBM Blade center system ONLY. 

Mininum system requirement: walltime=3:00:00,pmem=2gb,nodes=4:ppn=2

Suggest system requirement: walltime=3:00:00,pmem=3gb,nodes=8:ppn=2


Files/folders structure:

Beta-Code: Folder that contains source code, header files, and PBS
           scripts.

depracated: Folder that contains all the old codes, and previous relase.

Beta-Report: Folder that contains all documentations.

sample data: Folder that contains two sets of testing data.

gpl.txt: A copy of GNU Public License.
