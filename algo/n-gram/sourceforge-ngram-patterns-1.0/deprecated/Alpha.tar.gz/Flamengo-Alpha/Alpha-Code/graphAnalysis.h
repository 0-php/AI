#include<mpi.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "analyze.h"

int master;  // This variable stores the current master of each process.
int *numNetworks;
// This variable stores the number of networks when this processor assumes a master
int *nxtMaster;
// This variable is used for changing the control to the next master.
int totalNetworks;
// This variable contains the value of the 
void graphInit(int _master , int _id);
// This method should be called to be analyzing the network
void networkAnalysis(int id , node** ptrword, int arraySize, int np);
// This method performs the tasks of finding out the number of networks in a processor
void generateOutput(int id, node** ptrword , int arraySize , int np);
// This method generates the output.