#include "analyze.h"

network_info* new_network_info(int _id)
{
	network_info* _n_info;
	_n_info = (network_info*)malloc(sizeof(network_info));
	_n_info->id = _id;
	_n_info->total_weight = 0;
	_n_info->num_node = 0;
	_n_info->num_edge =0;
	return _n_info;
}

int analyze_network(node** node_pool, int size)
{
	int network_id, last_unseen;
	int i;
	network_id = 0;
	last_unseen = 0;
	while ((i = has_checked_all(node_pool, size, last_unseen)) != -1)
	{
		network_id++;
		last_unseen = i + 1;
		check_all_branch(node_pool[i], node_pool, network_id);
	}
	return network_id;
}

void check_all_branch(node* _node, node** node_pool, int id)
{
	if (_node->has_seen != id)
	{
		_node->has_seen = id;
		edge* temp;
		temp = _node->incoming;
		while (temp != NULL)
		{
			if (node_pool[temp->index]->is_checked == 0)
				check_all_branch(node_pool[temp->index], node_pool, id);
			temp = temp->next;
		}
		temp = _node->outgoing;
		while (temp != NULL)
		{
			if (node_pool[temp->index]->is_checked == 0)
				check_all_branch(node_pool[temp->index], node_pool, id);
			temp = temp->next;
		}
		_node->is_checked = id;
	}
}

int has_checked_all(node** node_pool, int size, int start_index)
{
	int i;
	for (i = start_index; i < size; i++)
	{
		if (node_pool[i]->has_seen == 0)
			return i;
	}
	return -1;
}

network_info** collect_network_info(node** node_pool, int size, int num_network)
{
	int i, j, id;
	edge* temp;
	network_info** _network_info;
	_network_info = (network_info**)malloc((num_network + 1) * sizeof(network_info*));
	for (i = 0; i < num_network + 1; i++)
		_network_info[i] = new_network_info(i);

	for (i = 0; i < size; i++)
	{
		id = node_pool[i]->is_checked;
		temp = node_pool[i]->outgoing;
		while (temp != NULL)
		{
			_network_info[id]->total_weight += temp->freq;
			_network_info[0]->total_weight += temp->freq;
			temp = temp->next;
		}
		_network_info[id]->num_edge += node_pool[i]->count_outgoing;
		_network_info[0]->num_edge += node_pool[i]->count_outgoing;
		_network_info[id]->num_node++;
		_network_info[0]->num_node++;
	}
	return _network_info;
}

void print(network_info** _n_info, int network_size)
{
	int i;
	for (i = 0; i < network_size + 1; i++)
	{
		printf("Network %d:\nTotal Weight: %d\nNumber of nodes: %d\nNumber of edges: %d\n",
				_n_info[i]->id,
				_n_info[i]->total_weight,
				_n_info[i]->num_node,
				_n_info[i]->num_edge);
	}
}

void op_combine(int* input, int* result, int* length, MPI_Datatype* dtype)
{
	int i, count;
	int* temp;
	temp = (int*)malloc(sizeof(int) * (*length));
	for (i = 0; i < *length; i++)
	{
		temp[i] = result[i];
		result[i] = 0;
	}

	count = 1;
	for (i = 0; i < *length; i++)
	{
		int tmp;
		MPI_Comm_rank(MPI_COMM_WORLD, &tmp);
		printf("Processor %d is working on %d element\n", tmp, i);
		if (input[i] == 0 && temp[i] != 0)
		{
			if (result[i] == 0)
			{
				update_id(temp, result, *length, temp[i], count);
				count++;
			}
			else
				update_id(temp, result, *length, temp[i], result[i]);
		}
		else if (temp[i] == 0 && input[i] != 0)
		{
			if (result[i] == 0)
			{
				update_id(input, result, *length, input[i], count);
				count++;
			}
			else
				update_id(input, result, *length, input[i], result[i]);
		}
		else if(temp[i] != 0 && input[i] != 0)
		{
			if (result[i] == 0)
			{
				update_id(input, result, *length, input[i], count);
				update_id(temp, result, *length, temp[i], count);
				count++;
			}
			else
			{
				update_id(input, result, *length, input[i], result[i]);
				update_id(temp, result, *length, temp[i], result[i]);
			}
		}
	}
}

void update_id(int* input, int* result, int size, int old_id, int new_id)
{
	int i;
	for (i = 0; i < size; i++)
	{
		if (input[i] == old_id)
		{
			if (result[i] == 0)
				result[i] = new_id;
			else if (result[i] != new_id)
			{
				int temp = result[i];
				result[i] = new_id;
				update_id(result, result, size, temp, new_id);
			}
		}
	}
}

int sort_id(int* array, int size)
{
	int count, i, j, id;
	count = 1;
	for (i = 0; i < size; i++)
	{
		if (array[i] > count)
		{
			count++;
			id = array[i];
			for (j = i; j < size; j++)
			{
				if (array[j] == id)
					array[j] = count;
				else if(array[j] == count)
					array[j] = id;
			}
		}	
	}
	return count;
}
