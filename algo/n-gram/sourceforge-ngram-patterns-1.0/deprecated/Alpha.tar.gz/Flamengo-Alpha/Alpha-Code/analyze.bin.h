/*
File: analyze.h
Author: Bin Lan <lanxx019@d.umn.edu>
Class: CS8621
Professor: Dr. Ted Pedersen
License: GPL

This file contains the functions used for analysis the network structures.
*/

#include "network.h"
#include "mpi.h"
#ifndef ANALYZE_H
#define ANALYZE_H

/*
network_info is the structure for storing the network informations. id is the unique 
identify number of the network. total_weight store the sum of weights of all the deges in
the network. num_edge stands for number of edges, and num_node stands for number of nodes.This structure was created mostly for the sequential program. Its use in the parallel code
has not been decided yet.
*/   

typedef struct network_info
{
	int id;
	int total_weight;
	int num_node;
	int num_edge;
}network_info;

/*
The constructor for a network_info structure. Only assign the network id, all other fields
are initialized to 0

_id: id number of the network
*/
network_info* new_network_info(int _id);

/*
analyze_network analysis a network's structure and assign each node with a unique id so all
nodes with the same id are connected in the network. Otherwise, they are disconnected.

Idea: every token in the unigram data array has two checking bit.                      
is_checked and has seen, they were initialized to be 0. We will go                     
through all the array to check each token to make sure that: if a                      
token has been seen before, then we go in the incoming and outgoing                    
linked list to mark all connected token's has_seen bit, after this,                    
we mark the current tolen as is_checked with a network ID. In this                     
case, we make sure we not only see every token but also all the tokens                 
that connect to it, so that we can sure we cover every nodes in the                    
network. Also, we use a ID number to mark both checking bits so we                     
can automatically decide how many networks are there and which network                 
this token is belonged to.

node_pool: unigram token array
size: size of the unigram data                                                         
*/                               
int analyze_network(node** node_pool, int size);

/*
A recursive function which checks all the directly connected children of a node. The node
will be marked as is_checked after the process. All the nodes involve in this process will
be mark both has_seen and is_checked with id.

_node: the node which is being checked.
node_pool: the array of all the network nodes.
id: the network id.
*/   
void check_all_branch(node* _node, node** node_pool, int id);

/*
Check if the there is any nodes in the array still has not been seen by any other nodes.
If so, the process will return the index of the node in the array, otherwise, return -1.

node_pool: the array of all the nodes in the network.
size: the number of the nodes.
start_index: the index of the last node we check that has not been seen before. 
*/   
int has_checked_all(node** node_pool, int size, int start_index);

/*
The sequential function for collecting all the network informations. Is is not being used
in the parallel code. This function will going through the whole node array and check each
node's id number and add the node, edge, weight information into the corresponding network_info container.

node_pool: array of all the network nodes.
size: number of nodes in the network.
num_network: number of connected networks return by analyze_network. 
*/   
network_info** collect_network_info(node** node_pool, int size, int num_network);

/*
Print all the network information.

_n_info: the network_info array that stores all the network information.
network_size: number of connected networks.
*/   
void print(network_info** _n_info, int network_size);

/*
A customized MPI reduce function for gathering network information. It accepts two int arrays.
These two arrays should contains the network id information from two different processors.
The function compare the id information between two arrays for the same node and update the
result array with the information it gathers from both input arrays.

input: the local result for MPI.
result: the global result for MPI.
length: number of nodes in the network.
dtype: it is not being used.
*/   
void op_combine(int* input, int* result, int* length, MPI_Datatype* dtype);

/*
Using the information provided by op_combine. This function should update the id in the result
array.

input: the input array where the function gets the network id information.
result: the output array.
old_id: all the element in input array that has old_id value will be updated to new_id.
new_id: we replace ole_id by new_id. 
*/   
void update_id(int* input, int* result, int size, int old_id, int new_id);

/*
Sort the id array so all id's will be in order. After op_combine, the network id information
is not sorted, namely, we might have networ 1, 2, 5 and 7. But we do not have networ 3, 4,
and 6. After the function, we should have network 1, 2, 3, and 4 instead.

array: id array we need to sort.
size: size of this array.
*/   
int sort_id(int* array, int size);

#endif
