#include "analyze.h"
#include <mpi.h>
/*network_info* new_network_info(int _id)
{
	network_info* _n_info;
	_n_info = (network_info*)malloc(sizeof(network_info));
	_n_info->id = _id;
	_n_info->total_weight = 0;
	_n_info->num_node = 0;
	_n_info->num_edge
	}   

void new_network_info(int _id, int _numEdges)
{
  int counter;
  localNetworks* _tempnet;
  _tempnet = networkList->_net;
  for(counter = 0; networkList->next!=NULL ; counter++)
     _tempnet = networkList->next;  
  
  networkInfo* newNetwork;
  newNetwork = (networkInfo*)malloc(sizeof(networkInfo));
  _tempnet->next = newNetwork;
  _tempnet = _tempnet->next;
  _tempnet = NULL;

  newNetwork->id = _id;
  newNetwork->total_weight = 0;
  newNetwork->num_node = 0;
  newNetwork->num_edge = _numEdges;
        
} */

/* If the processor is a master then, this method is called.*/
int master_analyze_network(node** node_pool, int size, int master_id, int numProcs , int numNetworks ,int* nxtMaster)
{
        int network_id;
        int last_unseen;
	int i, counter;
        int *numNodes;
        int  *numEdges;
        numNodes = (int*)malloc(sizeof(int));
        numEdges = (int*)malloc(sizeof(int));
        *numNodes = 0;
        *numEdges = 0;
        counter = 0;
	network_id = numNetworks;
	last_unseen = 0;
        //printf(" master analyze method entered ");
  	while ((i = has_checked_all(node_pool, size, last_unseen,      master_id , numProcs)) != -1)     /* find the node that is not yet present in any network */
  	{
	        *numEdges = 0;
                network_id++;
		//printf(" The network id is %d ",network_id);
                last_unseen = i + 1;
                check_all_branch(node_pool[i], node_pool, network_id, i , master_id , numProcs, numNodes , numEdges); /* Perform a DFS search */
                counter++;
                
                //printf(" The total number of nodes in the master are %d ",*numNodes);
                //printf(" The number of edges for %d for network %d with %d as master",*numEdges, network_id, master_id);
		//int temp;
                //temp = *numEdges;
                //printf(" Master: The master id is %d ", master_id);
                //MPI_Reduce(&temp, numEdges , 1 , MPI_INT , MPI_SUM , master_id , MPI_COMM_WORLD);
		// printf(" From Master: The total number of edges are %d ",*numEdges);
                
        }
        int end=-1;
        broadcast_Message(end,master_id,numProcs); /* Broad cast when the master is finished checking all its nodes */
	broadcast_Message(network_id, master_id, numProcs);
        if(master_id == numProcs-1)
	  {
            end = -2;
            broadcast_Message(end, master_id,numProcs);
            *nxtMaster = -1;
          }
        else
          {
	    broadcast_Message(master_id+1, master_id, numProcs);
            *nxtMaster = master_id+1;
          }

        // Receive the messages from slaves regarding thier networks and and number of edges.
        int sNetworkId, sNumEdges;
        MPI_Status status;
        
        /*for(counter = 0 ; counter < numProcs ; counter++)
	  {
	    if(counter== master_id)
              continue;
            else
            {
              MPI_Recv(&sNetworkId, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG , MPI_COMM_WORLD, &status);
              MPI_Recv(&sNumEdges , 1 , MPI_INT, MPI_ANY_SOURCE , MPI_ANY_TAG , MPI_COMM_WORLD , &status);
              printf(" The network id is: %d ",sNetworkId);
              printf(" The number of edges are: %d ",sNumEdges);
  	    }
	    } */
  
        return network_id;
}
/*
this method is called by the slaves */
int slave_analyze_network(node** node_pool , int size , int* totalNetworks , int* nxtMaster , int numProcs)
//int slave_analyze_network()
{
  int index, network_id;
  MPI_Status status;
  int *numNodes;
  int *numEdges;
  numNodes = (int*)malloc(sizeof(int));
  numEdges = (int*)malloc(sizeof(int));
  *numNodes = 0;
  *numEdges = 0;
  while(1)
    {
      // Receive the message passed first. This message has in it the index of word that is being searched in the master.
      MPI_Recv(&index, 1 , MPI_INT , MPI_ANY_SOURCE , MPI_ANY_TAG ,MPI_COMM_WORLD, &status); /* Receive the index of the word that needs to be checked by the slave */

      // If the master has finished with all its words, then it indicates so with the sending of message with data -1.
      // Therefore, break this loop if the master has finished dividing all its words.
      //printf(" The received index is %d of network %d");
      if(index == -1)  /* If the master has finished broadcasting, then */
       {
         //printf(" End of the search ");
         int temp;
         //int temp2;
         MPI_Recv(totalNetworks, 1 , MPI_INT , MPI_ANY_SOURCE , MPI_ANY_TAG , MPI_COMM_WORLD, &status);
         MPI_Recv(nxtMaster , 1 , MPI_INT , MPI_ANY_SOURCE , MPI_ANY_TAG , MPI_COMM_WORLD, &status);  
         //*totalNetworks = temp1; *nxtMaster = temp2;
         temp = *nxtMaster;
         if(temp == -2)
	 {
           temp = numProcs-1;
	   //send the network id and number of edges in it.
         } 
         else         
	 {
           temp = *nxtMaster - 1;
           // send the network id and the number of edges in it.
         }
         //int dummy;
         //MPI_Reduce(numEdges , &dummy ,1, MPI_INT , MPI_SUM, temp , MPI_COMM_WORLD);
         //printf(" \nFrom Slave: The master is  %d \n ",temp);
         //printf("From Slave: The number edges are: %d ",*numEdges);
         break;
       } 
      // Receive the network id in which the word pointed to by the index variable is present. 
      MPI_Recv(&network_id , 1, MPI_INT , MPI_ANY_SOURCE , MPI_ANY_TAG ,MPI_COMM_WORLD, &status);
      //printf("From Slave: The token of the string to be searched is %s ",node_pool[index]->token);
      //printf("From Slave: The network id is: %d ",network_id);
      //printf(" The received index is %d of network %d ",index,network_id);     

      // Thus at this stage we have the index of the word in the array and the network id to which it belongs to. 
      // Therefore now, perform the check using the function, check_all_brach() method. 
     if(node_pool[index]->incoming !=NULL || node_pool[index]->outgoing!=NULL)
        check_all_branch(node_pool[index], node_pool, network_id, index, -1, -1,numNodes, numEdges);
     else
       node_pool[index]->has_seen = network_id;     
 
    }
  return network_id;

}      
// this method broadcasts the values over to every slave.
void broadcast_Message(int _content , int _master_id , int _numProcs)
{
  int counter;
  for(counter = 0 ; counter < _numProcs ; counter++)
    {
      if(counter == _master_id)
	continue;
      else
	{
	  MPI_Send(&_content,1,MPI_INT,counter,0,MPI_COMM_WORLD);
        }  
 
    }
}
/* this method performs the DFS search */
void check_all_branch(node* _node, node** node_pool, int id, int i , int _master_id , int _numProcs, int* numNodes , int* numEdges)
{
    
  int counter;
  int* dummy;
  dummy = (int*)malloc(sizeof(int));
  if(_master_id != -1)
    {
   broadcast_Message(i, _master_id , _numProcs);
   broadcast_Message(id, _master_id, _numProcs);
   //printf(" The value being broadcasted is %s ", _node->token);
    }
	if (_node->has_seen != id)
	{
		_node->has_seen = id;
		edge* temp;
		temp = _node->incoming;
		while (temp != NULL)
		{
		  //printf("INCOMMING: %s <- %s  ",_node->token,node_pool[temp->index]->token);
			if (node_pool[temp->index]->is_checked == 0)
			  {
			        check_all_branch(node_pool[temp->index], node_pool, id ,temp->index , _master_id, _numProcs, numNodes , numEdges);
                                
                          }
			temp = temp->next;
		}
		temp = _node->outgoing;
		while (temp != NULL)
		{
		  //printf(" OUTGOING: %s -> %s ",_node->token,node_pool[temp->index]->token);
			if (node_pool[temp->index]->is_checked == 0)
				{
                                   check_all_branch(node_pool[temp->index], node_pool, id, temp->index, _master_id, _numProcs, numNodes , numEdges);
                                   
                                }
			temp = temp->next;
		}
		*numNodes = *numNodes+1;
                _node->is_checked = id;
		temp=_node->incoming;
                while(temp != NULL)
		  {
                    temp=temp->next;
                    *numEdges = *numEdges+1;
                  }
	}
}
/* This method checks for nodes that have not been classified into networks. */
int has_checked_all(node** node_pool, int size, int start_index, int _master_id , int _numProcs)
{
	int i;
	for (i = start_index; i < size; i++)
	{
		if (node_pool[i]->has_seen == 0 && (node_pool[i]->incoming!=NULL || node_pool[i]->outgoing!=NULL))
			return i;
                if (node_pool[i]->has_seen !=0)
		  {
                     broadcast_Message(i, _master_id , _numProcs);
                     broadcast_Message(node_pool[i]->has_seen , _master_id , _numProcs);
		  }
             
	}
	return -1;
}

/*void collect_network_info(node** node_pool, int size, int num_network, network_info** _network_info)
{
	int i, j, id;
	edge* temp;
	_network_info = (network_info**)malloc(num_network * sizeof(network_info*));
	for (i = 0; i < num_network; i++)
		_network_info[i] = new_network_info(i);

	for (i = 0; i < size; i++)
	{
		id = node_pool[i]->is_checked - 1;
		temp = node_pool[i]->outgoing;
		while (temp != NULL)
		{
			_network_info[id]->total_weight += temp->freq;
			temp = temp->next;
		}
		_network_info[id]->num_edge += node_pool[i]->count_outgoing;
		_network_info[id]->num_node++;
	}
}*/
