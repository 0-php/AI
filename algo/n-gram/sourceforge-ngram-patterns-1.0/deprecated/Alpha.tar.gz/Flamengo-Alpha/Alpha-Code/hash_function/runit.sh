#!/bin/bash -l
module load pathscale
mpicc 2gram_try.c hash.c
qsub -q bc script.sh
#
# ==== end of the sample script file ====

