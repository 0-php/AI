#ifndef _FLOYD_ALGO_H
#define _FLOYD_ALGO_H


struct two_gram_incoming
{
        int index; // index is the index from the vocab array of the newly added element
        int count; // frequency of the two tokens taken togather
        struct two_gram_incoming *next; // pointer to the next node of type two_gram_incoming
};

typedef struct two_gram_incoming two_gram_incoming;

struct two_gram_outgoing
{
        int index; // index is the index from the vocab array of the newly added element
        int count; // frequency of the two tokens taken togather
        struct two_gram_outgoing *next; // pointer to the next node of type two_gram_outgoing
};

typedef struct two_gram_outgoing two_gram_outgoing;

typedef struct
{
        char str[50];
        two_gram_incoming *i_list;
    two_gram_outgoing *o_list;
}vocab_r; // represents a vocab node

#endif

