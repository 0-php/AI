
/*
SUBMITTED BY:- Anurag Jain
DATE:- 11/07/07
COURSE NAME:- CS 8621
*/

/*------------------------2gm Read Try---------------------------------
Task
----
To read a 2gm google data file as fast as possible to build the network.  

Reason To Do That
------------------
Searching the index of a token is the most time consuming task due to the
choice of data structures. Although there was a cost with searching using 
these data structures but we chose them thinking they might help in our  
beta stage implementation.

My Data Structures
-----------------
The data structures i have used follow the same basic structure that we
have used in our beta stage implementation. I am using these data structures
to just demonstrate what work i did as there were issues when i tried
to integrate my code in our final code.


Data Strcutres Of Use
---------------------

1) vocab_r 
   -------
It is a data structure which can store a 50 character token and the incoming 
and outgoing pointers to the connected tokens in the 2gm file. 

2) two_gram_incoming and two_gram_outging
   --------------------------------------
They are similar in structure and represent node connection with other node.
Instead of keeping a string here we keep the index of the node. 
Frequency of occuring with the connected word togather.
And, Pointer to the next node.

3) vocab_array
   -----------
   It is an array of type vocab_r.

Working, Observations And Conclusions
-------------------------------------
We read the 2gm file first into the vocab_array data structure of the type
vocab_r.

Then we start reading the 2gm file.
So we need the indices of the tokens.

Searching the vocab_array by comparing each of its string was afcourse out
of question considering the size of the 2gm file to be 10000000.

I tried parallelizing the searching using the #pragma omp parallel for and
was able to bring the searching time to a constant. But it was still to much
and the problem was we cannot use (break) statement inside the omp parallel
for. I tired finding a way out of it but it didnt work.

Next, i thought of using the searching approach that we use to find a word in
a dictionary.

We first find the first letter, then the second and so on till we reach the token
we want.

UTF-8
-----
The problem then was the character set is not the Latin Character or even the ASCII
set. The data is un the UTF-8 format. This format uses a maximum of four octets
to represent characters from different languages. 

UTF-8 format takes variable number of bytes. 1 byte or more.
Ques: What does it mean?
Ans: It means that in UTF-8 format we can represent a Japanese charachter using 2
bytes whereas the A using 1 byte. It can take upto four octets i.e. four bytes of 
memory.

Similar to the UTF 8 format are the UTF 16 (takes 2 bytes or more) and
UTF 32 (which takes the maximum of four bytes i believe its fixed.)
The advantage in using UTF 8 instead of UTF 32 is that it saves memory
for characters that do not require four bytes to be representd.

Ques: Big Question was does it even matter when we are using out normal C functions 
to read strings like fscanf etc?
Ans: I dont think, it really does.

So if, you have a statement like

char str[50];
fscanf(fp, "%s",  str);

then the string in file with UTF format is read and stored at vocab_array[i].str.

Ques: When does it matter??
Ans: If you try using the strlen function and trying to find out all the tokens in 
the vocab list with length 1. It only prints tokens which take one byte of memory 
space to be stored. For eg: it will not print the chracter in the end of the vocab 
list.

String comparison has no problem. We can use strcmp.

Imp Obs:
------------
If you write a statement like:
printf("%c", str[0]);

It will print the UTF-8 character even if it takes more than one byte of memory.


Ok finally,
minimum length of character in vocab list = 1
maximum length of character in vocab list = 40.


Hash Function
-------------
Decided on the dictionary approach to find the index of a token from the whole list
i started working on it.

Things That Needed To Be Done For This Approach
-----------------------------------------------
We need to do bookeeping while reading the vocab file which can assist us with the 
fast searching of the indices. 

What do we need to bookeep?
--------------------------
We need to keep the:
1) Address of the first character of the token.
2) Keep the offset of the second character with respect to first character.
3) Keep the offset of the third character with respect to the combination of the
   first and second character and so on.

When should we bookeep?
----------------------
When we are reading the vocab file.

How should we bookeep?
---------------------
Analyzing the data i realized that the characters between ASCII 33-126 have the highest
frequency in the data and other letters do not occur that frequently.

So i decided that i will use 126-33+1 = 94 characters for bookeeping and tackle the rest of
them differently.

I decided to bookkeep for the first four charaters. 
What i am trying to say here is if the token is 4 character long and all the characters are 
between 33-126 inclusive. The we can return the index in linear time. Else we have to search.

I kept 4 arrays.
1) First 94*4 bytes - Stores the indices of the 94 characters.
2) Second 94*94*4 bytes - Stores the offsets of the 94 characters with respect to the 
                          first character.
3) Third 94*94*94*4 bytes. - Stores the offsets of the 94 characters with respect to the 
                             combination of first and second character.
4) Fourth 94*94*94*94*4 bytes - Stores the offsets of the 94 characters with respect to 
                                the first, second and third character.

I decided to stop at four character instead of the 5 or more because the memory requirements
we too much for that.

I did one more thing and i found it really nice.
I stored the address of characters in the array at their ASCII value. That is the address or offset
of the character if present at index(ascii value) in the array.

Eg:
Token A
Address in array is at 65-33 = 32nd location in the array. I subtracted 33 because we are keeping a 
94 element array.

i.e ! which has ascii value 33 is stored at the 0th location in the array.

Remark:- I found it really nice as we dont have to search the array for this character.
So we are doing thing faster.

One final thing i did was i noticed that characters with ASCII values not between 33-126 i.e. 
non latin characters and SPACE key (ASCII 32) start occuring from 13565325 location the vocab
file. So we can start our search from there if the token starts with one of such characters or
if it is the SPACE KEY.

Timings:-
-------
With this approach we can calculate the indices of  approximately 1000000 tokens in one hour.  


--------------------------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mpi.h"
#include "hash.h"

void read_2gm_file(FILE *);

// Global Variables
vocab_r *vocab_array;

int main (int argc, char *argv[])
{
int id, size;
int i, j;
init_hash_arr();
char xcount[10];
FILE * pFile;

MPI_Init (&argc, &argv);
MPI_Comm_rank (MPI_COMM_WORLD, &id);
MPI_Comm_size (MPI_COMM_WORLD, &size);
if(id == 0)
{
pFile = fopen ("/scratch1/pedersen/google-ngram/dvd1/data/1gms/vocab","r");
vocab_array = (vocab_r*)malloc(sizeof(vocab_r)*13588391);

for(i=0; i<13588391 ; i++)
{
 fscanf (pFile, "%s", vocab_array[i].str);
 fscanf (pFile, "%s", xcount);
 build_hash_arrays(vocab_array[i].str, i);
 vocab_array[i].i_list = NULL;
 vocab_array[i].o_list = NULL;
}

fclose (pFile);
pFile = fopen ("/scratch1/pedersen/google-ngram/dvd1/data/2gms/2gm-0000", "r");
      read_2gm_file(pFile);

fclose (pFile);
}



fflush (stdout);
MPI_Finalize();
return 0;
}

void read_2gm_file(FILE *xFile)
{
	
	int temp_index1 = -1;
	int temp_index2 = -1;
	int temp_count = -1;
	char str_temp[50];
        int i;
	
	while(!feof(xFile))
	{	
	fscanf(xFile, "%s", str_temp);
	temp_index1 = find_index(str_temp, vocab_array);
	printf("\nWord 1: %d |  ", temp_index1);
	
	fscanf(xFile, "%s", str_temp);
	temp_index2 = find_index(str_temp, vocab_array); 
        printf("Word 2: %d", temp_index2);


	fscanf(xFile, "%d", &temp_count);

	if(temp_index1 > -1 && temp_index2 > -1)
	{

		 two_gram_incoming *i_node;
		 two_gram_outgoing *o_node;

                 i_node = (two_gram_incoming*)malloc(sizeof(two_gram_incoming)*1);

	         o_node = (two_gram_outgoing*)malloc(sizeof(two_gram_outgoing)*1);

		 
		 i_node->index = temp_index1;
		 i_node->count = temp_count;
		 i_node->next = NULL; 

		 o_node->index = temp_index2;
        	 o_node->count = temp_count;
	         o_node->next = NULL;
		 if(vocab_array[temp_index1].o_list == NULL)
        	 {
	          vocab_array[temp_index1].o_list = o_node;
		 }
        	 else
	         {
                  two_gram_outgoing* temp_ptr_o = NULL;
                  temp_ptr_o = vocab_array[temp_index1].o_list;
	          if(temp_ptr_o->next == NULL)
		  {
		   temp_ptr_o->next = o_node;
		  }
		  else
		  {
		   while(temp_ptr_o->next != NULL)
                   temp_ptr_o = temp_ptr_o->next;
		   temp_ptr_o->next = o_node;	
		  }
                 }
		
		 if(vocab_array[temp_index2].i_list == NULL)
		 {
	          vocab_array[temp_index2].i_list = i_node;					
		 }
		 else
		 {
		  two_gram_incoming* temp_ptr_i = NULL;
		  temp_ptr_i = vocab_array[temp_index2].i_list;
		  if(temp_ptr_i->next == NULL)
		   temp_ptr_i->next = i_node;
		  else
		  {
		   while(temp_ptr_i->next != NULL)
		   temp_ptr_i = temp_ptr_i->next;
		   temp_ptr_i->next = i_node;
		  }
                 }

		
	}
	}

}


