#include "graphAnalysis.h"

/* This file contains the methods that parallelize the depth first search. This code starts off with processor 0 and the increments untill the last processor */

/* Initialize the variables that are used to determine which processor is in control */
void graphInit(int _master ,int _id)
{
  
  if(_id == 0)
    totalNetworks = 0;

  master = 0;
  numNetworks = (int*)malloc(sizeof(int));    /* this variable holds the value of the number of networks in its data set. */

  nxtMaster  = (int*)malloc(sizeof(int)); /* Contains the id of the next master.*/
}


/* The function networkAnalysis determines if the processor calling it master or a slave. If the processor is a master then it broadcasts the word for which it performs the depth first search. If the processor is a slave, then, it receive the word and performs a DFS on it's own data.*/
void networkAnalysis(int id, node**ptrword ,int  arraySize , int np)
{


      while(1)
      {
	if(id == master)
	{
	  totalNetworks = master_analyze_network(ptrword, arraySize , id , np , totalNetworks , nxtMaster);           if(*nxtMaster == -1)
	    {
              
              printf(" The total number of networks are: %d",totalNetworks); 
              int *nodeInfo;
              int counter;
              //nodeInfo = (int*)malloc(totalNetworks*sizeof(int));
              break;
            }
	  master = *nxtMaster;
        }
      else  /* If the network is not a master, then it is a slave */                                          
	{
        slave_analyze_network(ptrword, arraySize , numNetworks , nxtMaster, np);
          totalNetworks = *numNetworks;      
          if(*nxtMaster == -2)   /* If the master under control finishes then break. */
            break;
          master = *nxtMaster;         
        }
      }


}
 
/* generate output that tells the information about the network */
void generateOutput(int id, node** ptrword , int arraySize , int np)
{
  int counter;
  for(counter = 0; counter < arraySize ; counter++)
    printf(" The ids are: %d for word %s", ptrword[counter]->has_seen, ptrword[counter]->token);
  
 
}   
